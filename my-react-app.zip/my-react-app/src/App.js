import React from 'react';
import Greeter from './Greeter'; //Importi the Greeter component

function App() {
  return (
    <div>
      <h1> Welcome to My React App!</h1>
      <Greeter /> {/* Use the Greeter component*/}
    </div>
  );
}

export default App;
