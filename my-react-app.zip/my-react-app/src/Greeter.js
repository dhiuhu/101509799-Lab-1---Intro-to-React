import React from 'react';

function Greeter() {
  return <h2>Hello, React!</h2>;
}

export default Greeter;